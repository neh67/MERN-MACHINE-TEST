const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

mongoose.connect('mongodb://127.0.0.1:27017/lnt')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Failed to connect to MongoDB', err));

const schema = mongoose.Schema;

const loginSchema = new schema({
  srNo: Number,
  userName: String,
  password: String,
});

const employeeSchema = new schema({
  f_Id: Number,
  f_Image: String,
  f_Name: String,
  f_Email: String,
  f_Mobile: String,
  f_Designation: String,
  f_gender: String,
  f_Course: String,
  f_Createdate: Date,
});

const MyLogin = mongoose.model('logins', loginSchema);
const Employee = mongoose.model('employees', employeeSchema);

const app = express(); 
app.use(express.json());
app.use(cors());

app.post('/loginUser', async (req, res) => {
  const { userName, password } = req.body;

  if (!userName || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  try {
   
    const user = await MyLogin.findOne({ userName });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

  
    const isPasswordCorrect = user.password === password; 

    if (!isPasswordCorrect) {
      return res.status(401).json({ message: 'Incorrect username or password' });
    }
    console.log(user);
    return res.status(200).json({
      message: 'Login successful',
      user: {
        id: user._id,
        userName: user.userName,
        email: user.email,
      },
    });
  } catch (error) {
    console.error('Error occurred during login:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
});


app.post('/addEmployee', async (req, res) => {
  
  const { f_Id, f_Image, f_Name, f_Email, f_Mobile, f_Designation, f_gender, f_Course, f_Createdate } = req.body;
  const currentDate = new Date();
  const formattedDate = currentDate.toISOString().split('T')[0];
  if (!f_Id || !f_Name || !f_Email || !f_Mobile || !f_Designation || !f_gender || !f_Course) {
    return res.status(400).json({ message: 'All employee fields are required' });
  }

  try {
    const newEmployee = new Employee({
      f_Id,
      f_Image,
      f_Name,
      f_Email,
      f_Mobile,
      f_Designation,
      f_gender,
      f_Course,
      f_Createdate: formattedDate
    });

    await newEmployee.save();
    res.status(201).json({ message: 'Employee added successfully', employee: newEmployee });
  } catch (error) {
    console.error('Error occurred while adding employee:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.put("/updateEmployee/:id", async (req, res) => {
  const { id } = req.params;
  const updatedData = req.body;

  try {
    const result = await Employee.findByIdAndUpdate(id, updatedData, {
      new: true,
    }); // Update the employee by ID
    res.status(200).json({ message: "Employee updated successfully", employee: result });
  } catch (error) {
    res.status(500).json({ message: "Error updating employee", error });
  }
});

app.get('/getEmployees', async (req, res) => {
  
  try {
    const employees = await Employee.find();  

    console.log(employees);
    if (employees.length === 0) {
      
      return res.status(404).json({ message: 'No employees found' });
    }
    res.status(200).json({ message: 'Employees fetched successfully', employees });
  } catch (error) {
    console.error('Error occurred while fetching employees:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.listen(4010, () => {
  console.log('Server is running on 4010');
});
