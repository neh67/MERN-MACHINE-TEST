import axios from "axios";
import React, { useEffect, useState } from "react";

export default function ShowEmp() {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    // Fetch employees on component mount
    axios
      .get("http://localhost:4010/getEmployees")
      .then((res) => {
        if (res.data && Array.isArray(res.data.employees)) {
          setEmployees(res.data.employees);
        } else {
          console.error("Unexpected response format:", res.data);
        }
      })
      .catch((err) => {
        console.error("Error fetching employees:", err);
      });
  }, []);

  // Open modal and set selected employee for editing
  const handleEdit = (employee) => {
    setSelectedEmployee(employee);
    setShowModal(true);
  };

  // Handle input change in the form
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelectedEmployee((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Save the updated employee info
  const handleSave = () => {
    if (!selectedEmployee) return;

    axios
      .put(
        `http://localhost:4010/updateEmployee/${selectedEmployee._id}`,
        selectedEmployee
      )
      .then((res) => {
        console.log("Employee updated:", res.data);
        setEmployees((prev) =>
          prev.map((emp) =>
            emp._id === selectedEmployee._id ? { ...emp, ...res.data.employee } : emp
          )
        );
        setShowModal(false); // Close modal
      })
      .catch((err) => {
        console.error("Error updating employee:", err);
      });
  };

  return (
    <div className="container">
      <div className="row">
        <div className="border border-solid">
          <div className="row text-center">
            <h2>Employee Details</h2>
          </div>
          <table className="table table-striped mt-3">
            <thead>
              <tr className="border">
                <th>Employee ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Mobile No</th>
                <th>Email ID</th>
                <th>Gender</th>
                <th>Designation</th>
                <th>Course</th>
                <th>Edit</th>
              </tr>
            </thead>
            <tbody>
              {employees && employees.length > 0 ? (
                employees.map((employee) => (
                  <tr key={employee._id}>
                    <td className="border">{employee.f_Id}</td>
                    <td className="border">
                      {employee.f_Image ? (
                        <img
                          src={employee.f_Image}
                          alt={employee.f_Name}
                          style={{ width: "50px", height: "50px", borderRadius: "50%" }}
                        />
                      ) : (
                        "No Image"
                      )}
                    </td>
                    <td className="border">{employee.f_Name}</td>
                    <td className="border">{employee.f_Mobile}</td>
                    <td className="border">{employee.f_Email}</td>
                    <td className="border">{employee.f_gender}</td>
                    <td className="border">{employee.f_Designation}</td>
                    <td className="border">{employee.f_Course}</td>
                    <td className="border">
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => handleEdit(employee)}
                      >
                        Edit
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="9" className="text-center">
                    No Employee Data Found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for editing employee */}
      {showModal && selectedEmployee && (
        <div className="modal" style={{ display: "block" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit Employee</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                <form>
                  <div className="mb-3">
                    <label htmlFor="f_Name" className="form-label">
                      Name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="f_Name"
                      name="f_Name"
                      value={selectedEmployee.f_Name}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="f_Mobile" className="form-label">
                      Mobile No
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="f_Mobile"
                      name="f_Mobile"
                      value={selectedEmployee.f_Mobile}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="f_Email" className="form-label">
                      Email ID
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="f_Email"
                      name="f_Email"
                      value={selectedEmployee.f_Email}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="f_Designation" className="form-label">
                      Designation
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="f_Designation"
                      name="f_Designation"
                      value={selectedEmployee.f_Designation}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="f_Course" className="form-label">
                      Course
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="f_Course"
                      name="f_Course"
                      value={selectedEmployee.f_Course}
                      onChange={handleInputChange}
                    />
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowModal(false)}
                >
                  Close
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleSave}
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
