import React, { useEffect, useState } from 'react'
import {Link, useNavigate} from 'react-router-dom'
import Cookies from "js-cookie"; 

export default function() {
  const navigate = useNavigate();
  const [authenticated, setAuthenticated] = useState(false);
  const [userName, setUserName] = useState(false);

  useEffect(() => {
    const auth = Cookies.get('isAuthenticated') === 'true';
    const user = Cookies.get('userName');
    
    setAuthenticated(auth);
    setUserName(user || '');
  }, []);

  const loginHandle=()=>{
    navigate("/login");
  }
  const logoutHandle = () => {
    Cookies.set('isAuthenticated', 'false');
    Cookies.set('user', '');
    setAuthenticated(false);
    setUserName('');
    navigate("/");
    window.location.reload();
   
  };
  return (
    <div className='header'>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">Dashboard</Link>
          <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              {authenticated ? (
                <>
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/addEmployee">Add Employees</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/editEmployee">Edit Employees</Link>
                  </li>
                </>
              ) : null}
            </ul>

            <form className="d-flex" role="search">
              {authenticated ? (
                <>
                  <div className='userName' style={{marginRight:"20px"}}>{Cookies.get("user")}</div>
                  <button className="btn btn-outline-success" type="button" onClick={logoutHandle}>
                    Logout
                  </button>
                </>
              ) : (
                <Link className="btn btn-outline-success" to="/login" onClick={()=>{loginHandle()}}>Login</Link>
              )}
            </form>
          </div>
        </div>
      </nav>
    </div>
  );
}
