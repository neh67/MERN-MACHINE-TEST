import React, { useRef, useState} from "react";
import axios from "axios";

const AddEmp = () => {
  const f_IdRef = useRef();
  const f_NameRef = useRef();
  const f_EmailRef = useRef();
  const f_MobileRef = useRef();
  const f_DesignationRef = useRef();
  const f_genderRef = useRef();
  const f_CourseRef = useRef([]);
  const f_ImageRef = useRef();
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);



  const handleSubmit = async (e) => {
    e.preventDefault();

    const selectedCourses = Array.from(f_CourseRef.current)
      .filter((checkbox) => checkbox.checked)
      .map((checkbox) => checkbox.value);

    const employeeData = {
      f_Id: f_IdRef.current.value,
      f_Name: f_NameRef.current.value,
      f_Email: f_EmailRef.current.value,
      f_Mobile: f_MobileRef.current.value,
      f_Designation: f_DesignationRef.current.value,
      f_gender: f_genderRef.current.value,
      f_Course: selectedCourses.join(", "),
      f_Image: f_ImageRef.current.files[0]?.name || "",
    };

    if (!employeeData.f_Id || !employeeData.f_Name || !employeeData.f_Email) {
      setError("All fields are required!");
      return;
    }

    try {
      await axios.post("http://localhost:4010/addEmployee", employeeData);
      setSuccess("Employee added successfully!");
      setError(null);

    } catch (err) {
      setError("Failed to add employee. Try again.");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Add Employee</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
      <form onSubmit={handleSubmit}>
        {/* Employee Form Fields */}
        <div className="mb-3">
          <label htmlFor="employeeId" className="form-label">
            Employee ID
          </label>
          <input
            type="number"
            className="form-control"
            id="employeeId"
            placeholder="Enter Employee ID"
            ref={f_IdRef}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="fullName" className="form-label">
            Full Name
          </label>
          <input
            type="text"
            className="form-control"
            id="fullName"
            placeholder="Enter Full Name"
            ref={f_NameRef}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">
            Email
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            placeholder="Enter Email"
            ref={f_EmailRef}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="mobile" className="form-label">
            Mobile
          </label>
          <input
            type="text"
            className="form-control"
            id="mobile"
            placeholder="Enter Mobile Number"
            ref={f_MobileRef}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="designation" className="form-label">
            Designation
          </label>
          <select className="form-select" ref={f_DesignationRef}>
            <option>Manager</option>
            <option>Developer</option>
            <option>Tester</option>
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">Gender</label>
          <div>
            <input
              type="radio"
              name="gender"
              value="Male"
              ref={(el) => (f_genderRef.current = el)}
              className="form-check-input"
            />{" "}
            Male
            <input
              type="radio"
              name="gender"
              value="Female"
              ref={(el) => (f_genderRef.current = el)}
              className="form-check-input ms-3"
            />{" "}
            Female
          </div>
        </div>

        <div className="mb-3">
          <label className="form-label">Courses</label>
          <div>
            <input
              type="checkbox"
              value="React"
              ref={(el) => (f_CourseRef.current[0] = el)}
              className="form-check-input"
            />{" "}
            React
            <input
              type="checkbox"
              value="Node"
              ref={(el) => (f_CourseRef.current[1] = el)}
              className="form-check-input ms-3"
            />{" "}
            Node
            <input
              type="checkbox"
              value="Spring Boot"
              ref={(el) => (f_CourseRef.current[2] = el)}
              className="form-check-input ms-3"
            />{" "}
            Spring Boot
          </div>
        </div>

        <div className="mb-3">
          <label htmlFor="image" className="form-label">
            Image
          </label>
          <input type="file" className="form-control" ref={f_ImageRef} />
        </div>

        <button type="submit" className="btn btn-primary w-100">
          Add Employee
        </button>
      </form>
    </div>
  );
};

export default AddEmp;
