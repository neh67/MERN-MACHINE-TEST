import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Cookies from 'js-cookie';

export default function Dashboard() {
  const [authenticated, setAuthenticated] = useState(false);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    const auth = Cookies.get('isAuthenticated') === 'true';
    const user = Cookies.get('userName');
    
    setAuthenticated(auth);
    setUserName(user || '');
  }, []);

  const logoutHandle = () => {
    Cookies.set('isAuthenticated', 'false');
    Cookies.set('userName', '');
    setAuthenticated(false);
    setUserName('');
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-12 text-center">
          <h2>{authenticated ? `Welcome, ${userName}!` : 'Please Log In'}</h2>
        </div>
      </div>
    </div>
  );
}
