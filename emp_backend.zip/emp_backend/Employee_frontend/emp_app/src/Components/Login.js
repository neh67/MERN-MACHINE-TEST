import React, { useRef, useState } from "react";
import axios from "axios";

import Cookies from "js-cookie"; 
import { useNavigate } from "react-router-dom";

export default function Login() {
  const userNameRef = useRef();
  const passwordRef = useRef();
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    const userName = userNameRef.current.value;
    const password = passwordRef.current.value;
  
    if (!userName || !password) {
      setError("Username and password are required!");
      return;
    }
  
    try {
      const response = await axios.post("http://localhost:4010/loginUser", {
        userName,
        password,
      });
      if (response.status === 200) {
        alert("Login successful");
        console.log(response.data.user["userName"]);
        Cookies.set("user",response.data.user["userName"]);
        Cookies.set("isAuthenticated",true);
        navigate("/");
        window.location.reload();
      }
    } catch (error) {
      console.error(error);
      if (error.response) {
        if (error.response.status === 401) {
          setError("Incorrect username or password!");
        } else if (error.response.status === 404) {
          setError("User not found!");
        } else {
          setError("An unexpected error occurred.");
        }
      } else {
        setError("Unable to connect to the server. Please try again later.");
      }
    }
  };
  

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Login</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleLogin}>
        <div className="mb-3">
          <label htmlFor="username" className="form-label">
            Username
          </label>
          <input
            type="text"
            className="form-control"
            id="username"
            placeholder="Enter username"
            ref={userNameRef}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">
            Password
          </label>
          <input
            type="password"
            className="form-control"
            id="password"
            placeholder="Enter password"
            ref={passwordRef}
          />
        </div>
        <button type="submit" className="btn btn-primary w-100">
          Login
        </button>
      </form>
    </div>
  );
}
