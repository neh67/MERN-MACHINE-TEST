import * as React from "react";
import { createBrowserRouter } from "react-router-dom";
import Login from "./Components/Login";
import App from "./Components/App";
import AddEmp from "./Components/AddEmp";
import ShowEmp from "./Components/ShowEmp";
import Dashboard from "./Components/Dashboard";

const customRouter = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
        {
            path: "/",
            element:<Dashboard/>,
          },
      {
        path: "/login",
        element: <Login />,
      },
      {
        path: "/addEmployee",
        element: <AddEmp />,
      },
      {
        path: "/editEmployee",
        element: <ShowEmp/>
      }
    ],
  },
]);

export default customRouter;
